
	<div class="items" id="item<?php echo $s;?>" style="width:100%;">
			<img class="<?php echo $url_class;?>" src="<?php echo $url;?>" id="<?php echo $url_id;?>" width="1" height="1">
       
		<input type="hidden" id="item<?php echo $s;?>_merchantID" value="<?php echo $merchantID;?>">
		<input type="hidden" id="item<?php echo $s;?>_unit" value="<?php echo $unit;?>">
		<input type="hidden" id="item<?php echo $s;?>_unitID" value="<?php echo $unitID;?>">
		<input type="hidden" id="item<?php echo $s;?>_name" value="<?php echo $productname;?>">
		<input type="hidden" id="item<?php echo $s;?>_price" value="<?php echo $price;?>">
		<div class="card-content">
			<p>QUANTITY: <input type="text" id="item<?php echo $s;?>_qty" value="1" align="center" size="10" style="text-align:center; width:80px;"> vehicle(s)</p>
			<p>DURATION: <input type="text" id="item<?php echo $s;?>_duration" value="1" align="center" size="10" style="text-align:center; width:80px;"> day(s)</p>
		</div>
		<input type="hidden" id="item<?php echo $s;?>_pID" value="<?php echo $productID;?>">
		<button onclick="cart('item<?php echo $s;?>')" href="#" class="cd-add-to-cart" style=" margin-left:30px;">Add To Cart</button>
	</div>
