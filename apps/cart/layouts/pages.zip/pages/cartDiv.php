<div id="id01" class="w3-modal" style="display: none;">
  <!-- Modal content -->
	<div class="modal-body" style="margin-right:auto; margin-left:auto; background-color:#ccc; color:#000; width:350px;">
	<div id="mycart" style=" "></div>
	</div>
</div>
<div id="id02" class="w3-modal" style="display: none;">
  <!-- Modal content -->
	<div class="modal-body" style="margin-right:auto; margin-left:auto; background-color:#ccc; color:#000; width:350px;">
	<div id="mycart" style=" "></div>
	</div>
</div>