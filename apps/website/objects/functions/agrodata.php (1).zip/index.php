<?php
include find_file("apps/website/objects/functions/jobs.php");
include find_file("apps/website/objects/functions/news.php");
include find_file("apps/website/objects/functions/privacy.php");
include find_file("apps/website/objects/functions/subterms.php");
include find_file("apps/website/objects/functions/terms.php");
include find_file("apps/website/objects/functions/vehicles.php");
include find_file("apps/website/objects/functions/gui.php");
include find_file("apps/website/objects/functions/geo.php");
include find_file("apps/website/objects/functions/vp_vehicles.php");
?>